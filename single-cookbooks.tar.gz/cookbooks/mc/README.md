# mc

TODO: Enter the cookbook description here.

# chef-mc
